/* Script da Questão 3 */

// Parte 2:
alert('Olá, mundo!')